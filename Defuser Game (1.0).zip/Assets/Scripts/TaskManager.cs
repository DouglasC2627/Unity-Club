﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TaskManager : MonoBehaviour { // Configuration for managing scripts.

    public GameSetting setting; // Inheritance, also see Start()
    public GameObjectives obj;

    void Start() {
        setting = GetComponent<GameSetting>();
        obj = GetComponent<GameObjectives>();

        StartLevel();
    }

    void StartLevel() {
        setting.ResetLevel();
    }

    public void Submit() {
        obj.CheckCompletion();
    }

    public void Win() {
        setting.textM.text = "  You defused the bomb!";
    }

    public void Lose() {
        setting.textM.text = "  Oh no";
    }

    public void OpenMenu() {
        StartLevel(); // restart. TODO add more options in menu
        Debug.Log("Menu should open here.");
    }
}
