﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameObjectives : MonoBehaviour { // configuration for winning condition

    public TaskManager mng;
    public GameSetting setting;

    private bool success = false;
    private bool obj1 = false;
    private bool obj2 = false;
    private bool obj3 = false;


    private void Start() {
        mng = GetComponent<TaskManager>();
        setting = GetComponent<GameSetting>();
    }

    public void CheckCompletion() {
        obj1 = setting.hitsAND == 2;
        obj2 = setting.hitsOR == 5;
        obj3 = setting.hitsNOT == 0;
        success = obj1 && obj2 && obj3;
        Debug.Log("success is " + success);
        LevelClear();
    }

    public void LevelClear() {
        if (success) {
            mng.Win();
        } else {
            mng.Lose();
        }
    }
}
