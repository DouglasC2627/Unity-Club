﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameSetting : MonoBehaviour { // configuration for mechanic design.

    public TaskManager mng;

    public Text textM;
    public Text text1;
    public Text text2;
    public Text text3;

    public int hitsReturn = 0;
    public int hitsAND = 0;
    public int hitsOR = 0;
    public int hitsNOT = 0;

    public void Start() {
        mng = GetComponent<TaskManager>();
    }

    public void ClickReturn() { // Daily reminder to set public for button OnClick()
        hitsReturn++;
        Debug.Log("hitsReturn returns " + hitsReturn);
        ClearText();
        mng.Submit();
    }

    public void ClickAND() {
        hitsAND++;
        Debug.Log("hitsAND returns " + hitsAND);
        ClearText();
    }

    public void ClickOR() {
        hitsOR++;
        Debug.Log("hitsOR returns " + hitsOR);
        ClearText();
    }

    public void ClickNOT() {
        hitsNOT++;
        Debug.Log("hitsNOT returns " + hitsNOT);
        ClearText();
    }

    private void ClearText() {
        textM.text = "";
        text1.text = "";
        text2.text = "";
        text3.text = "";
    }

    public void ResetLevel() { // Reset variables; reset text.
        hitsReturn = 0;
        hitsAND = 0;
        hitsOR = 0;
        hitsNOT = 0;
        text1.text = "DO NOT PRESS NOT!";
        text2.text = "PRESS ME or ME or ME or ME or ME!";
        text3.text = "PRESS AND THINK TWICE!";
        textM.text = "  owo a bomb!";
    }
}
